var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["7b4144b5-c26d-441e-98d5-226550c9612a"],"propsByKey":{"7b4144b5-c26d-441e-98d5-226550c9612a":{"name":"animalhead_fox","sourceUrl":null,"frameSize":{"x":306,"y":316},"frameCount":1,"looping":true,"frameDelay":12,"version":"asnAt_nAMZ_WUOczBM_E6cKMVZ0bz.8d","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":306,"y":316},"rootRelativePath":"assets/7b4144b5-c26d-441e-98d5-226550c9612a.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var sprite1 = createSprite(200, 300, 20, 20);
sprite1.shapeColor = "white";

var sprite2 = createSprite(180, 320, 20, 20);
sprite2.shapeColor = "blue";

var sprite3 = createSprite(220, 320, 20, 20);
sprite3.shapeColor = "blue";

var sprite4 = createSprite(160, 340, 20, 20);
sprite4.shapeColor = "red";

var sprite5 = createSprite(200, 340, 20, 20);
sprite5.shapeColor = "white";

var sprite6 = createSprite(240, 340, 20, 20);
sprite6.shapeColor = "red";

var squariad = createSprite(200, 200, 20, 25);
squariad.velocityX = 4;
squariad.velocityY = 5;
squariad.shapeColor = "yellow";






function draw() {
 background("black");
 if (keyDown("up")) {
  sprite1.y=sprite1.y-5 ;
 }
 if (keyDown("down")) {
  sprite1.y=sprite1.y+5 ;
 }
 if (keyDown("left")) {
  sprite1.x=sprite1.x-5 ;
 }
 if (keyDown("right")) {
  sprite1.x=sprite1.x+5;
}
if (keyDown("up")) {
  sprite2.y=sprite2.y-5 ;
 }
 if (keyDown("down")) {
  sprite2.y=sprite2.y+5 ;
 }
 if (keyDown("left")) {
  sprite2.x=sprite2.x-5 ;
 }
 if (keyDown("right")) {
  sprite2.x=sprite2.x+5;
}
 if (keyDown("up")) {
  sprite3.y=sprite3.y-5 ;
 }
 if (keyDown("down")) {
  sprite3.y=sprite3.y+5 ;
 }
 if (keyDown("left")) {
  sprite3.x=sprite3.x-5 ;
 }
 if (keyDown("right")) {
  sprite3.x=sprite3.x+5;
}
if (keyDown("up")) {
  sprite4.y=sprite4.y-5 ;
 }
 if (keyDown("down")) {
  sprite4.y=sprite4.y+5 ;
 }
 if (keyDown("left")) {
  sprite4.x=sprite4.x-5 ;
 }
 if (keyDown("right")) {
  sprite4.x=sprite4.x+5;
}
if (keyDown("up")) {
  sprite5.y=sprite5.y-5 ;
 }
 if (keyDown("down")) {
  sprite5.y=sprite5.y+5 ;
 }
 if (keyDown("left")) {
  sprite5.x=sprite5.x-5 ;
 }
 if (keyDown("right")) {
  sprite5.x=sprite5.x+5;
}
if (keyDown("up")) {
  sprite6.y=sprite6.y-5 ;
 }
 if (keyDown("down")) {
  sprite6.y=sprite6.y+5 ;
 }
 if (keyDown("left")) {
  sprite6.x=sprite6.x-5 ;
 }
 if (keyDown("right")) {
  sprite6.x=sprite6.x+5;
}

drawSprites();
 
 createEdgeSprites();
 squariad.bounceOff(topEdge);
 squariad.bounceOff(bottomEdge);
 squariad.bounceOff(rightEdge);
 squariad.bounceOff(leftEdge);
 squariad.bounceOff(sprite1);
 squariad.bounceOff(sprite2);
 squariad.bounceOff(sprite3);
 squariad.bounceOff(sprite4);
 squariad.bounceOff(sprite5);
 squariad.bounceOff(sprite6);
 sprite1.bounceOff(topEdge);
 sprite1.bounceOff(bottomEdge);
 sprite1.bounceOff(rightEdge);
 sprite1.bounceOff(leftEdge);
 sprite2.bounceOff(topEdge);
 sprite2.bounceOff(bottomEdge);
 sprite2.bounceOff(rightEdge);
 sprite2.bounceOff(leftEdge);
 sprite3.bounceOff(topEdge);
 sprite3.bounceOff(bottomEdge);
 sprite3.bounceOff(rightEdge);
 sprite3.bounceOff(leftEdge);
 sprite4.bounceOff(topEdge);
 sprite4.bounceOff(bottomEdge);
 sprite4.bounceOff(rightEdge);
 sprite4.bounceOff(leftEdge); 
 sprite5.bounceOff(topEdge);
 sprite5.bounceOff(bottomEdge);
 sprite5.bounceOff(rightEdge);
 sprite5.bounceOff(leftEdge);
 sprite6.bounceOff(topEdge);
 sprite6.bounceOff(bottomEdge);
 sprite6.bounceOff(rightEdge);
 sprite6.bounceOff(leftEdge);
 
 
 
 
 
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
